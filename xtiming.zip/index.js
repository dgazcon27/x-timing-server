const axios = require("axios");
const moment = require('moment');
const graylog2 = require('graylog2');
require("dotenv").config()

const PROJECT = {
  "continuidad_de_Aplicaciones_cr": 19,
  "continuidad_de_Aplicaciones_gt":24,
  "continuidad_de_Aplicaciones_sv":29,
  "continuidad_de_Aplicaciones_ve":34,
  "Intelix": 66
}

const ACTIVITY = {
  "microservicios_caja_nueva": 240,
  "caja_registradora_gt": 303,
  "caja_registradora_sv": 359,
  "caja_registradora_ve": 423,
  "Feriado": 907
}

const postActivities = () => {
    const url = process.env.X_HOST
    const user = process.env.X_USER
    const pass = process.env.X_PASS
 
    const activities = [
      {
        "begin": "2023-08-21T07:30:00",
        "end": "2023-08-21T11:30:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Implementacion de logs graylog para modulo recordRefund",
        "tags": "Desarrollo"
      },
      {
        "begin": "2023-08-21T12:31:00",
        "end": "2023-08-21T14:31:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Revision de datos para envio de articulos a t2 QA y actualizacion de articulos",
        "tags": "Desarrollo"
      },
      {
        "begin": "2023-08-21T14:32:00",
        "end": "2023-08-21T16:31:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Actualizacion de fichas en tienda 3 para equipo de procesos EPA CR",
        "tags": "Desarrollo"
      },
      {
        "begin": "2023-08-22T07:31:00",
        "end": "2023-08-22T11:31:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Analisis de tarea: implementacion de endpoint para envio de cliente y renovar dias de credito corporativo",
        "tags": "Análisis"
      },
      {
        "begin": "2023-08-22T12:31:00",
        "end": "2023-08-22T16:31:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Creacion de endpoint para consultar cliente y realizar envio de cliente por xml soap a bopos",
        "tags": "Desarrollo"
      },
      {
        "begin": "2023-08-23T07:30:00",
        "end": "2023-08-23T11:30:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Limpieza de codigos de articulos para envio masivo para actualizacion de articulos en tienda 3",
        "tags": "Desarrollo"
      },
      {
        "begin": "2023-08-23T12:30:00",
        "end": "2023-08-23T16:30:00",
        "project": PROJECT['continuidad_de_Aplicaciones_cr'],
        "activity": ACTIVITY['microservicios_caja_nueva'],
        "description": "Implementacion de funcion para envio de cliente y renovar dias de credito corporativo",
        "tags": "Desarrollo"
      }
    ]

    const listOfPromise = activities.map(item => new Promise((resolve, reject) => {
      axios.post(url, JSON.stringify(item), {
        headers: {
          'Content-Type': 'application/json',
          'X-AUTH-USER': user,
          'X-AUTH-TOKEN': pass
        }
      })
      .then(function (response) {
        resolve(response.data)
      })
      .catch(function (error) {
        console.log(error);
        reject(error)
      });
    }))

    Promise.all(listOfPromise)
    .then(response => {
      console.log(response)
    })
    .catch(err => {
      console.log(err)
    })
}


postActivities();

