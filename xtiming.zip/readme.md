Inicializar las variables de entorno 

USER
PASS
HOST